
public class Const {
    public static final int TAM_MAX_DATA = 4000;
    public static final int TAM_MAX_MSG = TAM_MAX_DATA + 4*4;
}